package com.sbt.softwarebugtracker.model;

public enum ProjectStatus {
    ACTIVE,
    COMPLETED,
    ON_HOLD,
    IN_PROGRESS,
    IN_TESTING,
}
