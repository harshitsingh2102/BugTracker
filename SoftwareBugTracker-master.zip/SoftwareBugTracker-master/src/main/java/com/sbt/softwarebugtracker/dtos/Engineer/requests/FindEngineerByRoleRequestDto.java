package com.sbt.softwarebugtracker.dtos.Engineer.requests;

public class FindEngineerByRoleRequestDto {

}
