package com.sbt.softwarebugtracker.service;

public interface ProjectService {
}
