package com.sbt.softwarebugtracker.model;

public enum EngineerRole {
    FULLSTACK,
    FRONTEND,
    BACKEND,
    QUALITY_ASSURANCE,
    DEVOPS
}
