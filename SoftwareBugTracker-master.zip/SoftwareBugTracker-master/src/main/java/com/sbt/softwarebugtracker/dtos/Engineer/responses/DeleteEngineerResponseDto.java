package com.sbt.softwarebugtracker.dtos.Engineer.responses;

import lombok.Data;

@Data
public class DeleteEngineerResponseDto {
    private String details;
    private String message;
}
