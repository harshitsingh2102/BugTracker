package com.sbt.softwarebugtracker.dtos.Engineer.responses;

import lombok.Data;

@Data
public class UpdateEngineerResponseDto {
    private String details;
}
