package com.sbt.softwarebugtracker.dtos.Bug.requests;

import lombok.Data;

@Data
public class CreateBugReportRequestDto {

}
