package com.sbt.softwarebugtracker.dtos.Project.requests;

import lombok.Data;

@Data
public class UpdateProjectRequestDto {

}
