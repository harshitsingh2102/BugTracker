package com.sbt.softwarebugtracker.dtos.Engineer.responses;

import lombok.Data;

@Data
public class FindEngineerByRoleResponseDto {


}
