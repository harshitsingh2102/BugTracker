package com.sbt.softwarebugtracker.exceptions;

public class SBTException extends RuntimeException {
    public SBTException(String message) {super(message);
    }
}
