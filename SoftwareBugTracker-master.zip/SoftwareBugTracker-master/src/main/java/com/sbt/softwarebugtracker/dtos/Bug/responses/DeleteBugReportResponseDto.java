package com.sbt.softwarebugtracker.dtos.Bug.responses;

public class DeleteBugReportResponseDto {
}
