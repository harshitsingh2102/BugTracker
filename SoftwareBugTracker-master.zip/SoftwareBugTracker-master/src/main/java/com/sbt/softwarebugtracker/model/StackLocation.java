package com.sbt.softwarebugtracker.model;

public enum StackLocation {
    FRONTEND,
    BACKEND,
    DATABASE
}
