package com.sbt.softwarebugtracker.dtos.Engineer.requests;

import lombok.Data;

@Data
public class FetchAllEngineerRequestDto {

}
