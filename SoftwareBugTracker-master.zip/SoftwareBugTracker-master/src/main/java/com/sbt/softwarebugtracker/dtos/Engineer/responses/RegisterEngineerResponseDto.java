package com.sbt.softwarebugtracker.dtos.Engineer.responses;

import lombok.Data;

@Data
public class RegisterEngineerResponseDto {
    private String details;
    private String message;
}
