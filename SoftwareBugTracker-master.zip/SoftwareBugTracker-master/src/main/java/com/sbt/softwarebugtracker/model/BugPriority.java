package com.sbt.softwarebugtracker.model;

public enum BugPriority {
    LOW,
    MEDIUM,
    HIGH,
    IMMEDIATE
}
