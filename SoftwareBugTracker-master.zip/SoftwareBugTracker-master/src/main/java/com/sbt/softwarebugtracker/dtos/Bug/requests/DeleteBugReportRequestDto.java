package com.sbt.softwarebugtracker.dtos.Bug.requests;

public class DeleteBugReportRequestDto {
}
