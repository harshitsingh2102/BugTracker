package com.sbt.softwarebugtracker.model;

public enum BugStatus {
    OPEN,
    CLOSED,
    IN_PROGRESS,
    OVERDUE,
}
