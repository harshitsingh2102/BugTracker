package com.sbt.softwarebugtracker.dtos.Project.response;

import lombok.Data;

@Data
public class DeleteProjectResponseDto {
}
