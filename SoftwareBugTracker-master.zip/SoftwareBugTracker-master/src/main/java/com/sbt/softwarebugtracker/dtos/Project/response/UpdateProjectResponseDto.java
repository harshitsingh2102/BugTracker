package com.sbt.softwarebugtracker.dtos.Project.response;

public class UpdateProjectResponseDto {
}
