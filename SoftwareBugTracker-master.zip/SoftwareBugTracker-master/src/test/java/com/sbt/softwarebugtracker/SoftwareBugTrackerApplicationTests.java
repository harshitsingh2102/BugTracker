package com.sbt.softwarebugtracker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SoftwareBugTrackerApplicationTests {

    @Test
    void contextLoads() {
    }

}
